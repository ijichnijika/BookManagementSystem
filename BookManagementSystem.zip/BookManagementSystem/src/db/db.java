package db;

import java.sql.*;

public class db {
    private Connection dbConn;
    private Statement stateMent;

    public db() {
        String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        String dbURL = "jdbc:sqlserver://localhost:1433;DatabaseName=pay0924";
        String userName = "sa";
        String userPWD = "waxyf2022";

        try {
            Class.forName(driverName);
            dbConn = DriverManager.getConnection(dbURL, userName, userPWD);
            System.out.println("Connection Successful!");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            dbConn = null;  // Ensure dbConn is null if connection fails
        }
    }

    // 执行更新操作
    public int executeUpdate(String sql) throws SQLException {
        if (dbConn == null) {
            throw new SQLException("Database connection is not established.");
        }
        stateMent = dbConn.createStatement();
        return stateMent.executeUpdate(sql);
    }

    // 执行查询操作
    public ResultSet executeQuery(String sql) throws SQLException {
        if (dbConn == null) {
            throw new SQLException("Database connection is not established.");
        }
        stateMent = dbConn.createStatement();
        return stateMent.executeQuery(sql);
    }

    // 关闭连接
    public void closeConn() throws SQLException {
        if (stateMent != null) {
            stateMent.close();
        }
        if (dbConn != null) {
            dbConn.close();
        }
    }

    // 创建 PreparedStatement 对象
    public PreparedStatement PreparedStatement(String sql) throws SQLException {
        if (dbConn == null) {
            throw new SQLException("Database connection is not established.");
        }
        return dbConn.prepareStatement(sql);
    }

    // 创建 CallableStatement 对象
    public CallableStatement cstmt(String callProc) throws SQLException {
        if (dbConn == null) {
            throw new SQLException("Database connection is not established.");
        }
        return dbConn.prepareCall(callProc);
    }


}
