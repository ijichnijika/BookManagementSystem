package entity;
public class ReaderEntity {

}
